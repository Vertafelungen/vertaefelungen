# Product Overview

This folder contains all product categories that are publicly documented. Each category has its own subfolder with a README file and associated product entries.

## Categories

- [High Wainscoting](high-wainscoting/)
- [Half-Height Paneling](half-height-paneling/)
- [Baseboards](baseboards/)
- [Wall Moldings](molding/)
- [Ventilation Rosettes](ventilation-rosettes/)
- [Oils and Colors](oils-and-colors/)
