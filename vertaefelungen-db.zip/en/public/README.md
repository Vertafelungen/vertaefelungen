# Public Content

This directory contains all information intended for external use by customers, partners or the general public. It includes:

- Product documentation by category (`products/`)
- Reference projects
- Materials and finishes
- Historical design inspirations

These resources form the knowledge base for client consulting, chatbots, documentation and digital services.
