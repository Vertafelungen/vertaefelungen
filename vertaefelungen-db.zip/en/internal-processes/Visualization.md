# Visualization and Quotation Workflow

## 1. Purpose
The visualization is used to accurately represent the planned wall paneling in the client's space. It supports:
- cost estimation,
- technical planning,
- and workshop preparation,
- installation.

## 2. Workflow
- The client submits a **floor plan or room sketch** (a smartphone photo of a plan is usually sufficient).
- Dimensions and ceiling height must be visible.
- Special features (windows, heaters, door trims) are clarified in advance.

## 3. Creation in SketchUp
- Import of the floor plan into Trimble SketchUp
- 3D model creation with scaled walls, door frames, window openings
- Adding typical paneling profiles (e.g. Baroque, Classical, Historicist)

## 4. Result
- Screenshots created for client approval
- Visualization is included at **10 % of the project cost**
- Once approved, a detailed drawing is prepared for the joinery

## 5. Communication Use
- Helps clients decide on style and height
- Optional: different molding variants, baseboards, color options
