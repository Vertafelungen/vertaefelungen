# Öffentliche Inhalte

In diesem Verzeichnis finden sich alle Informationen, die für Kunden, Partner oder externe Nutzer sichtbar sein sollen. Dazu gehören:

- Produktdokumentationen nach Kategorien (`produkte/`)
- Referenzprojekte
- Materialien & Oberflächen
- Historische Vorbilder der Gestaltung

Diese Inhalte bilden die Grundlage für Beratung, Chatbots, Dokumentationen und weitere digitale Services.
