# Produktübersicht

In diesem Verzeichnis befinden sich alle Produktkategorien, die öffentlich dokumentiert sind. Zu jeder Kategorie gibt es eigene Unterordner mit einer README-Datei und den jeweiligen Produkten.

## Kategorien

- [Hohe Vertäfelungen](hohe-vertaefelungen/)
- [Halbhohe Vertäfelungen (Lambris)](halbhohe-vertaefelungen/)
- [Sockelleisten](sockelleisten/)
- [Wandleisten](wandleisten/)
- [Lüftungsrosetten](lueftungsrosetten/)
- [Öle und Farben](oele-und-farben/)
