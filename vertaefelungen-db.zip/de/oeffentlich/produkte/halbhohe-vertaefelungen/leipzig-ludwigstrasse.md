# Leipzig – Ludwigstraße (P0006)

Dieser Lambris aus einem Hauseingang der Leipziger Ludwigstraße (Volkmarsdorf) stammt aus der Bauzeit des Gebäudes von 1884 und hat somit ein Alter von rund 140 Jahren. Diese Zeitspanne überbrückt fünf Generationen.

Anfertigung auf Bestellung – Lieferzeit ca. **6 Wochen**, zzgl. Versandkosten.

---

## Technische Angaben

- **Produktcode:** P0006  
- **Stil:** Gründerzeit  
- **Kategorie:** Hohe Vertäfelung  
- **Holzarten:** Kiefer oder Eiche  
- **Höhe:** ca. 135,5 cm  
- **Ausführung:** Rohbausatz oder komplett vormontiert  
- **Grundpreis:** ab 552,51 €/lfm (inkl. MwSt, zzgl. Lieferung)

---

## Hinweise

- Diese Vertäfelung wird originalgetreu reproduziert.
- Individuelle Breiten und Anpassungen auf Anfrage möglich.
