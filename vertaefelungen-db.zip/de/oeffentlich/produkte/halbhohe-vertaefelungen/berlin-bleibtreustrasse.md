# Berlin – Bleibtreustraße (P0005)

Sehr eindrucksvoll und trotzdem recht einfach aufgebaut.  
Durch die aneinander gereihten „Fenster“ mit den Dreipassbögen als Abschluss entsteht eine **neogotische Vertäfelung**.  
Solches Interieur verleiht einem gründerzeitlichen Hauseingang **Ansehen und Würde**.

Anfertigung auf Bestellung – Lieferzeit ca. **6 Wochen**, zzgl. Versand.

---

## Technische Details

- **Produktcode:** P0005  
- **Stil:** Neugotik / Gründerzeit  
- **Kategorie:** Hohe Vertäfelung  
- **Holzarten:** Kiefer (geölt oder farbig gestrichen)  
- **Höhe:** ca. 1300 mm  
- **Ausführung:** Bausatz oder vormontiert  
- **Grundpreis:** ab 1.073,13 € pro Laufmeter (inkl. MwSt., zzgl. Versand)

---

## Hinweise

- Auf Wunsch in jeder Farbe streichbar.  
- Rücksprünge und Maßanpassungen möglich.  
- Originalgetreue Reproduktion historischer Ausführung.
