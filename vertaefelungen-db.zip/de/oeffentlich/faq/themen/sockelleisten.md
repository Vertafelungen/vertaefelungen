---
title: "Fußleisten und Sockelleisten: Formen, Funktion, Restaurierung"
slug: "faq-fussleisten-sockelleisten"
kategorie: "FAQ"
tags: ["Sockelleisten", "Fußleisten", "Altbau", "Innenausbau", "Holzleisten", "Restaurierung"]
erstellt_am: "2025-07-28"
letzte_aenderung: "2025-07-28"
sichtbar: true
sprachversion: "de"
beschreibung: "FAQ zu Fußleisten und Sockelleisten: typische Profile, Verwendung, Materialien, Montage und Restaurierung im Altbau."
---

# FAQ: Fußleisten – Sockelleisten

## 1. Was sind Fußleisten und Sockelleisten?

Fußleisten (auch Sockelleisten genannt) sind horizontale Leisten aus Holz, die den Übergang zwischen Wand und Boden abdecken. Sie schützen die Wand vor Stößen und Verschmutzung und sorgen für einen sauberen Abschluss des Bodenbelags.

---

## 2. Welche Profile und Bauformen sind typisch?

- **Gerade Leisten:** schlicht, rechteckig oder leicht gefast
- **Profilierte Sockelleisten:** mit Rundung, Kehle, Stabprofil oder Gesims
- **Historische Sonderformen:** hohe, mehrfach gestufte Profile im Altbau
- **Individuelle Sonderprofile:** nach Vorlage oder Anpassung an vorhandene Leisten

---

## 3. Welche Hölzer werden verwendet?

Meist kommen Kiefer, Fichte, Eiche, Buche oder Linde zum Einsatz. Im Denkmalschutz wird auf das ursprüngliche Material und Faserbild geachtet.

---

## 4. Wo werden Sockelleisten eingesetzt?

- Im gesamten Wohnbereich, Fluren, Treppenhäusern und öffentlichen Gebäuden
- Besonders wichtig bei Holz- und Parkettböden
- Zur optischen Gliederung und als Stilmerkmal historischer Interieurs

---

## 5. Wie werden Sockelleisten montiert?

- Genagelt, geschraubt oder geklebt – abhängig von Wandmaterial und Anspruch
- Passgenaues Ablängen und Gehrungsschnitte für saubere Ecken
- Verdeckte Befestigung und sorgfältiges Schließen der Fugen
- Oberfläche meist roh, geölt, gewachst oder lackiert

---

## 6. Was ist bei Restaurierung und Nachfertigung zu beachten?

- Profilgenaue Nachfertigung anhand des Bestands (Schablonen, Muster)
- Materialtreue und Oberflächenangleichung für harmonisches Gesamtbild
- Schonende Demontage bei Sanierung, Reversibilität im Denkmalschutz

---

*Fragen zu Fußleisten oder individuellem Zuschnitt? Wir beraten gern zur Auswahl, Nachfertigung und Montage!*
