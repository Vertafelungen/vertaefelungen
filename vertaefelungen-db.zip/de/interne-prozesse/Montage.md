# Montageanleitung für Holzvertäfelungen

Diese Anleitung erklärt die grundlegenden Schritte zur Montage einer Wandvertäfelung in historischer oder klassischer Ausführung.

## 1. Vorbereitung
- Untergrund prüfen: tragfähig, trocken, eben
- Maße mit dem gelieferten Plan abgleichen
- Positionen für Steckdosen, Heizkörper usw. klären

## 2. Werkzeuge & Materialien
- Wasserwaage, Zollstock, Gehrungssäge, Bohrmaschine
- Montagekleber, Schrauben, ggf. verdeckte Clipsysteme
- Pläne, Leisten, Paneele, Profile laut Stückliste

## 3. Montageablauf
1. **Montagelatte setzen:** Waagerecht auf gewünschter Höhe befestigen  
2. **Paneele montieren:** Von der Mitte aus nach außen arbeiten  
3. **Zierleisten setzen:** Gehrungsschnitt, Anleimen oder -kleben  
4. **Aussparungen herstellen:** Steckdosen, Nischen etc.  
5. **Abschluss prüfen:** Oberfläche, Leimreste, ggf. Korrekturen

## 4. Oberflächenbehandlung
Werkseitig geölt, lackiert oder patiniert – alternativ kann die Endbehandlung nach Montage erfolgen.

## 5. Besonderheiten bei Denkmalprojekten
- Reversibilität beachten (keine Verklebung auf Originalputz)
- Rücksprache mit Fachstellen erforderlich

## 6. Sicherheit
- Elektroarbeiten nur durch Fachbetriebe
- Eigenmontage auf eigenes Risiko

👉 [PDF-Version herunterladen](./Montageanleitung.pdf)
